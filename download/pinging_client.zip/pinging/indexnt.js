var ping = require('ping');
const https = require('https');
const axios = require('axios')
var pingarray = [];
var outputJSON = [];
var errorsnmbr = 0;



function uploadJSON() {
    var uploadJSON = JSON.stringify(outputJSON);
    axios.post("http://35.210.42.4:8181/pingupload2?test=" + uploadJSON + "")
        .then(res => {
            process.stdout.write(" Upload: " + res.status);
            // console.log(res)
        })
        .catch(error => {
            //  console.error(error)
        })
}

function sendtoserver(resultping) {
    pingarray.push(resultping);
    outputJSON.push({ "ping": resultping, "timestamp": new Date() });
    process.stdout.write(" | ping: " + resultping);
    process.stdout.write("\n");
    process.stdout.write("-----------------------------------");
    process.stdout.write("\n");
    var aping = 0;
    for (i = 0; i < pingarray.length; i++) {
        aping = aping + pingarray[i];
    }
    aping = Math.round(aping / pingarray.length);

    process.stdout.write("Prum. ping: " + aping);
    process.stdout.write("\n");
    process.stdout.write("Errors: " + errorsnmbr);
    process.stdout.write("\n");
    process.stdout.write("Nmbr. of pings: " + pingarray.length);


}

function getTimeFnc() {
    var host = '1.1.1.1';
    var basetime = new Date().getTime();
    var resultping = 0;
    ping.sys.probe(host, function(isAlive, error) {
        resultping = new Date().getTime() - basetime;
        var msg = "error";
        if (isAlive == true) {
            msg = "✅ " + host;
        } else {
            msg = "❌ " + host;
            errorsnmbr++;
        }
        process.stdout.cursorTo(0, 5);
        process.stdout.clearLine(0);
        process.stdout.cursorTo(0, 4);

        process.stdout.cursorTo(0, 0);
        process.stdout.clearLine(0);


        process.stdout.write(msg);
        process.stdout.write(" | Error: " + error);

        sendtoserver(resultping);
    });

}

var timerunned = 0;

function loopm() {
    getTimeFnc();

    timerunned++;
    if (timerunned == 10) {
        uploadJSON();
        timerunned = 0;
    }


    setTimeout(function() {
        loopm();
    }, 5000);
}

console.clear()
loopm();