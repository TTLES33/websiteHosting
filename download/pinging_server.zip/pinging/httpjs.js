

function test(){
    var ctx = document.getElementById('myChart');
    ctx.style.width = document.getElementById('graph').clientWidth;
    ctx.style.height = "400px";
    var ctx2 = document.getElementById('myChart2');
    ctx2.style.width = document.getElementById('graph2').clientWidth;
    ctx2.style.height = "400px";

    $.ajax({
        method: "GET",
        url: 'http://localhost:8181/pingdata',
        success: function(result) {
            console.log(result);
        
            var pingdata1 = JSON.parse(JSON.parse(result[0]).test);
            console.log(pingdata1);
            var pingdata2 = JSON.parse(JSON.parse(result[1]).test);
            console.log(pingdata2);

            var o2pingover100 = 0;
            var o2pingsoucet = 0;
            var chartlabels1 = [];
            var chartdata1 = [];
            var ntpingover100 = 0;
            var ntpingsoucet = 0;
            var chartlabels2 = [];
            var chartdata2 = [];

            for (var i = 0; i < pingdata1.length; i++){
                console.log(pingdata1[i].ping);
                var pingdate = new Date(pingdata1[i].timestamp);
                var label = pingdate.getDate() + "." + pingdate.getMonth() + " " + pingdate.getHours() + ":" + pingdate.getMinutes() + ":" + pingdate.getSeconds();
                chartlabels1.push(label);
                chartdata1.push(pingdata1[i].ping);

                o2pingsoucet = o2pingsoucet + pingdata1[i].ping;
                if(pingdata1[i].ping > 100){
                    o2pingover100++;
                }   
            }
            console.log(o2pingover100);
            var o2prumping = Math.round(o2pingsoucet / pingdata1.length);
            console.log(o2prumping);
            document.getElementById("o2prumping").innerHTML = o2prumping;
            document.getElementById("o2pingnad100").innerHTML = o2pingover100;


            for (var i = 0; i < pingdata2.length; i++){
                console.log(pingdata2[i].ping);
                var pingdate = new Date(pingdata2[i].timestamp);
                var label = pingdate.getDate() + "." + pingdate.getMonth() + " " + pingdate.getHours() + ":" + pingdate.getMinutes() + ":" + pingdate.getSeconds();
                chartlabels2.push(label);
                chartdata2.push(pingdata2[i].ping);

            ntpingsoucet = ntpingsoucet + pingdata2[i].ping;
                if(pingdata2[i].ping > 100){
                    ntpingover100++;
                }   
            }
            console.log(ntpingover100);
            var ntprumping = Math.round(ntpingsoucet / pingdata2.length);
            console.log(ntprumping);
            document.getElementById("ntprumping").innerHTML = ntprumping;
            document.getElementById("ntpingnad100").innerHTML = ntpingover100;




            const myChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: chartlabels1,
                    
                    datasets: [{
                        label: 'o2 ping',
                        data: chartdata1,
                        borderColor: 
                            'rgba(255, 99, 132, 1)'
                        ,
                        borderWidth: 1
                    },
                    {
                      
                            label: 'nt ping',
                            data: chartdata2,
                            borderColor: 
                                'rgba(84,161,209,255)'
                            ,
                            borderWidth: 1
                    }]
                    
                },
              
                options: {
                    scales: {
                        y: {
                            ticks: {
                                color: "#b8b8b8",
                            }
                        },
                        x: {
                            ticks: {
                                color: "#b8b8b8",
                            }
                        }

                    },
                    responsive: false,
                    plugins: {
                        zoom: {
                          zoom: {
                            wheel: {
                              enabled: true,
                            },
                            pinch: {
                                enabled: true
                              },
                            mode: 'x',
                          }
                        }
                      },
            
                }
            });

            const myChart2 = new Chart(ctx2, {
                type: 'line',
                data: {
                    labels: chartlabels2,
                    
                    datasets: [{
                        label: 'NT ping',
                        data: chartdata2,
                        borderColor: 
                            'rgba(255, 99, 132, 1)'
                        ,
                        borderWidth: 1
                    }]
                },
              
                options: {
                    scales: {
                        y: {
                            ticks: {
                                color: "#b8b8b8",
                            }
                        },
                        x: {
                            ticks: {
                                color: "#b8b8b8",
                            }
                        }

                    },
                    responsive: false,
                    plugins: {
                        zoom: {
                          zoom: {
                            wheel: {
                              enabled: true,
                            },
                            pinch: {
                                enabled: true
                              },
                            mode: 'x',
                          }
                        }
                      },
            
                }
            });
        },
        error: function(xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });

}
