
var express = require('express');
const bodyParser = require("body-parser");
var app = express();
const router = express.Router();
const cors = require('cors');
const fs = require('fs')
app.use(cors({
origin: '*'

})); 

app.post('/pingupload1', function (req, res) {
    //console.log(req);
    var loginnickname = req.query;
    //console.log(loginnickname);
    var someoutput = JSON.stringify(req.query);
    console.log(someoutput);
    fs.writeFile('./output_1.json', someoutput, err => {
      if (err) {
        console.error(err);
        return;
      }
     

  }) 

  res.send("success");
}) 
app.post('/pingupload2', function (req, res) {
  //console.log(req);
  var loginnickname = req.query;
  //console.log(loginnickname);
  var someoutput = JSON.stringify(req.query);
  console.log(someoutput);
  fs.writeFile('./output_2.json', someoutput, err => {
    if (err) {
      console.error(err);
      return;
    }
   

}) 

res.send("success");
}) 

app.get('/pingdata', function (req, res) { 
  console.log("request");
  var outputdata = [];
  fs.readFile('./output_1.json', 'utf8', function(err, data){
      outputdata.push(data); 
      fs.readFile('./output_2.json', 'utf8', function(err, data){
        outputdata.push(data); 
        res.send(outputdata);
      });
});


   
})


  var server = app.listen(8181, function () {
    var host = server.address().address;
    var port = server.address().port;
    console.log("Example app listening at http://%s:%s", host, port);

})